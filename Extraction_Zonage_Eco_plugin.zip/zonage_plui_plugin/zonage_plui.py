# -*- coding: utf-8 -*-
"""
Plugin QGIS - Extraction des Zonages Économiques
Corrections : expressions LIKE correctes, choix département, couches optionnelles,
              combo NOM_M élargi.
"""

import os
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QMessageBox, QProgressBar,
    QGroupBox, QFileDialog, QLineEdit, QSizePolicy, QCheckBox
)
from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes, QgsProcessingFeedback
)
import processing


def classFactory(iface):
    return ZonagePLUiPlugin(iface)


# ─────────────────────────────────────────────────────────────────────────────
# Expressions par département
# ─────────────────────────────────────────────────────────────────────────────
DEPT_CONFIG = {
    "bas_rhin": {
        "label": "(UX, 1AUX, IAUX, 2AUX, IIAUX…)",
        "extract_expr": (
            "upper(\"libelle\") LIKE 'UX%' OR "
            "upper(\"libelle\") LIKE 'UX1%' OR "
            "upper(\"libelle\") LIKE '2AUX%' OR "
            "upper(\"libelle\") LIKE 'IIAUX%' OR "
            "upper(\"libelle\") LIKE '1AUX%' OR "
            "upper(\"libelle\") LIKE 'IAUX%'"
        ),
        "type_zone_expr": (
            "CASE "
            "WHEN upper(\"libelle\") LIKE 'UX%' OR upper(\"libelle\") LIKE 'UX1%' THEN 'U' "
            "WHEN upper(\"libelle\") LIKE '2AUX%' OR upper(\"libelle\") LIKE 'IIAUX%' THEN '2AU' "
            "WHEN upper(\"libelle\") LIKE '1AUX%' OR upper(\"libelle\") LIKE 'IAUX%' THEN '1AU' "
            "END"
        ),
    },
    "haut_rhin": {
        "label": "(UE, 1AUE, IAUE, 2AUE, II2AUE…)",
        "extract_expr": (
            "upper(\"libelle\") LIKE 'UE%' OR "
            "upper(\"libelle\") LIKE 'UE1%' OR "
            "upper(\"libelle\") LIKE '2AUE%' OR "
            "upper(\"libelle\") LIKE 'IIAUE%' OR "
            "upper(\"libelle\") LIKE '1AUE%' OR "
            "upper(\"libelle\") LIKE 'IAUE%'"
        ),
        "type_zone_expr": (
            "CASE "
            "WHEN upper(\"libelle\") LIKE 'UE%' OR upper(\"libelle\") LIKE 'UE1%' THEN 'U' "
            "WHEN upper(\"libelle\") LIKE '2AUE%' OR upper(\"libelle\") LIKE 'IIAUE%' THEN '2AU' "
            "WHEN upper(\"libelle\") LIKE '1AUE%' OR upper(\"libelle\") LIKE 'IAUE%' THEN '1AU' "
            "END"
        ),
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Thread de traitement
# ─────────────────────────────────────────────────────────────────────────────
class ProcessingThread(QThread):
    progress_changed = pyqtSignal(int, str)
    finished_ok      = pyqtSignal(object)
    finished_error   = pyqtSignal(str)

    def __init__(self, params):
        super().__init__()
        self.params = params

    def run(self):
        try:
            result = run_model(self.params, self.progress_changed)
            self.finished_ok.emit(result)
        except Exception as e:
            import traceback
            self.finished_error.emit(str(e) + "\n\n" + traceback.format_exc())


# ─────────────────────────────────────────────────────────────────────────────
# Logique de traitement
# ─────────────────────────────────────────────────────────────────────────────
def run_model(p, progress_signal=None):
    def step(pct, msg):
        if progress_signal:
            progress_signal.emit(pct, msg)

    feedback = QgsProcessingFeedback()
    dept = DEPT_CONFIG[p['dept_key']]
    extract_expr   = dept['extract_expr']
    type_zone_expr = dept['type_zone_expr']

    # ── Extraction EPCI ───────────────────────────────────────────────────────
    step(2, "Extraction de l'EPCI sélectionné…")
    nom_safe = p['NOM_M'].replace("'", "''")
    epci_single = processing.run("native:extractbyexpression", {
        'INPUT': p['epci_layer'],
        'EXPRESSION': "\"NOM_M\" = '" + nom_safe + "'",
        'OUTPUT': 'memory:'
    }, feedback=feedback)['OUTPUT']

    if epci_single.featureCount() == 0:
        raise ValueError("Aucune entité trouvée pour NOM_M = '" + p['NOM_M'] + "'")

    # ── Traitement de chaque source ───────────────────────────────────────────
    all_layers = []
    sources = p['sources']
    n_sources = len(sources)
    pct_per_source = 60 // max(n_sources, 1)

    for s_idx, source in enumerate(sources):
        src_layer = source['layer']
        src_type  = source['type']
        src_name  = src_layer.name()
        base = 5 + s_idx * pct_per_source

        step(base, "Réparation géométries " + src_name + "…")
        fixed_in = processing.run("native:fixgeometries", {
            'INPUT': src_layer, 'METHOD': 1, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        step(base + 2, "Découpage " + src_name + " par l'EPCI…")
        clipped = processing.run("native:clip", {
            'INPUT': fixed_in, 'OVERLAY': epci_single, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        if clipped.featureCount() == 0:
            step(base + pct_per_source, src_name + " — aucune entité dans l'EPCI, ignoré.")
            continue

        # Préparer le champ libelle pour CEREMA
        if src_type == 'cerema':
            step(base + 4, "Filtrage source GPU (CEREMA)…")
            expr_gpu = (
                "\"site_description\" NOT LIKE 'Source FF%' AND "
                "\"site_description\" NOT LIKE 'Source OSM%' AND "
                "\"site_description\" NOT LIKE 'Source BdTopo%' AND "
                "\"site_description\" NOT LIKE 'Source EMPCOM%'"
            )
            filtered = processing.run("native:extractbyexpression", {
                'INPUT': clipped, 'EXPRESSION': expr_gpu, 'OUTPUT': 'memory:'
            }, feedback=feedback)['OUTPUT']

            fields = [f.name() for f in filtered.fields()]
            if 'lib_zone' in fields and 'libelle' not in fields:
                clipped = processing.run("native:fieldcalculator", {
                    'INPUT': filtered, 'FIELD_NAME': 'libelle', 'FIELD_TYPE': 2,
                    'FIELD_LENGTH': 100, 'FIELD_PRECISION': 0,
                    'FORMULA': '"lib_zone"', 'OUTPUT': 'memory:'
                }, feedback=feedback)['OUTPUT']
            else:
                clipped = filtered

        step(base + 6, "Extraction zones économiques (" + src_name + ")…")
        extracted = processing.run("native:extractbyexpression", {
            'INPUT': clipped,
            'EXPRESSION': extract_expr,
            'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        if extracted.featureCount() == 0:
            step(base + pct_per_source, src_name + " — aucune zone éco trouvée, ignoré.")
            continue

        step(base + 8, "Calcul TYPE_ZONE (" + src_name + ")…")
        with_type = processing.run("native:fieldcalculator", {
            'INPUT': extracted, 'FIELD_NAME': 'TYPE_ZONE', 'FIELD_TYPE': 2,
            'FIELD_LENGTH': 255, 'FIELD_PRECISION': 0,
            'FORMULA': type_zone_expr, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        all_layers.append(with_type)

    if not all_layers:
        raise ValueError(
            "Aucune zone économique (U / 1AU / 2AU) trouvée pour cet EPCI.\n"
            "Vérifiez le département sélectionné (Bas-Rhin / Haut-Rhin) et les couches sources."
        )

    # ── Fusion de toutes les sources ──────────────────────────────────────────
    step(68, "Fusion de toutes les sources…")
    if len(all_layers) == 1:
        merge_all = all_layers[0]
    else:
        merge_all = processing.run("native:mergevectorlayers", {
            'LAYERS': all_layers, 'CRS': None, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

    # ── Snap → Fix → Dissolve par type ───────────────────────────────────────
    results_by_type = {}
    for idx, type_zone in enumerate(['U', '1AU', '2AU']):
        base = 70 + idx * 6

        step(base, "Extraction '" + type_zone + "'…")
        ext_type = processing.run("native:extractbyexpression", {
            'INPUT': merge_all,
            'EXPRESSION': "\"TYPE_ZONE\" = '" + type_zone + "'",
            'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        if ext_type.featureCount() == 0:
            continue

        step(base + 1, "Réparation '" + type_zone + "'…")
        fix1 = processing.run("native:fixgeometries", {
            'INPUT': ext_type, 'METHOD': 1, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        step(base + 2, "Accrochage '" + type_zone + "' (0.5m)…")
        snapped = processing.run("native:snapgeometries", {
            'INPUT': fix1, 'REFERENCE_LAYER': fix1,
            'TOLERANCE': 0.5, 'BEHAVIOR': 0, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        step(base + 3, "Réparation post-accrochage '" + type_zone + "'…")
        fix2 = processing.run("native:fixgeometries", {
            'INPUT': snapped, 'METHOD': 1, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        step(base + 4, "Dissolution '" + type_zone + "'…")
        dissolved = processing.run("native:dissolve", {
            'INPUT': fix2, 'FIELD': [], 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        step(base + 5, "Explosion multipolygones '" + type_zone + "'…")
        single = processing.run("native:multiparttosingleparts", {
            'INPUT': dissolved, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

        results_by_type[type_zone] = single

    if not results_by_type:
        raise ValueError("Aucun zonage U/1AU/2AU après dissolution.")

    # ── Fusion finale ─────────────────────────────────────────────────────────
    step(90, "Fusion finale U + 1AU + 2AU…")
    if len(results_by_type) == 1:
        merge_final = list(results_by_type.values())[0]
    else:
        merge_final = processing.run("native:mergevectorlayers", {
            'LAYERS': list(results_by_type.values()),
            'CRS': None, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

    # ── Nettoyage colonnes ────────────────────────────────────────────────────
    step(92, "Nettoyage colonnes…")
    cols_drop = ["layer", "path", "nom_doc_ur", "fid", "site_description",
                 "lib_zone", "idurba", "datappro", "libelong", "typezone",
                 "typezone_l", "nomfic", "urlfic", "datvalid"]
    existing  = [f.name() for f in merge_final.fields()]
    to_drop   = [c for c in cols_drop if c in existing]
    if to_drop:
        merge_final = processing.run("native:deletecolumn", {
            'INPUT': merge_final, 'COLUMN': to_drop, 'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

    # ── Ajout champs métier ───────────────────────────────────────────────────
    step(94, "Ajout champ NOTE…")
    existing = [f.name() for f in merge_final.fields()]
    if 'NOTE' not in existing:
        merge_final = processing.run("native:addfieldtoattributestable", {
            'INPUT': merge_final, 'FIELD_NAME': 'NOTE',
            'FIELD_TYPE': 2, 'FIELD_LENGTH': 255, 'FIELD_PRECISION': 0,
            'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

    step(96, "Ajout et remplissage NOM_M…")
    existing = [f.name() for f in merge_final.fields()]
    if 'NOM_M' not in existing:
        merge_final = processing.run("native:addfieldtoattributestable", {
            'INPUT': merge_final, 'FIELD_NAME': 'NOM_M',
            'FIELD_TYPE': 2, 'FIELD_LENGTH': 255, 'FIELD_PRECISION': 0,
            'OUTPUT': 'memory:'
        }, feedback=feedback)['OUTPUT']

    merge_final = processing.run("native:fieldcalculator", {
        'INPUT': merge_final, 'FIELD_NAME': 'NOM_M', 'FIELD_TYPE': 2,
        'FIELD_LENGTH': 255, 'FIELD_PRECISION': 0,
        'FORMULA': "'" + nom_safe + "'", 'OUTPUT': 'memory:'
    }, feedback=feedback)['OUTPUT']

    step(98, "Numérotation fid…")
    final_layer = processing.run("native:addautoincrementalfield", {
        'INPUT': merge_final, 'FIELD_NAME': 'fid',
        'START': 1, 'MODULUS': 0,
        'GROUP_FIELDS': [], 'SORT_EXPRESSION': '',
        'SORT_ASCENDING': True, 'SORT_NULLS_FIRST': False,
        'OUTPUT': p.get('output_path', 'memory:')
    }, feedback=feedback)['OUTPUT']

    step(100, "Terminé !")
    return final_layer


# ─────────────────────────────────────────────────────────────────────────────
# Plugin
# ─────────────────────────────────────────────────────────────────────────────
class ZonagePLUiPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(QIcon(icon_path),
                              "Extraction des Zonages Économiques",
                              self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Urbanisme", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("Urbanisme", self.action)

    def run(self):
        ZonagePLUiDialog(self.iface).exec_()


# ─────────────────────────────────────────────────────────────────────────────
# Dialogue
# ─────────────────────────────────────────────────────────────────────────────
class ZonagePLUiDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.thread = None
        self.setWindowTitle("Extraction des Zonages Économiques")
        self.setMinimumWidth(540)
        self.setWindowIcon(QIcon(os.path.join(self.plugin_dir, "icon.png")))
        self._build_ui()
        self._populate_layers()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(10)

        # ── En-tête ───────────────────────────────────────────────────────────
        hdr = QHBoxLayout()
        logo = QLabel()
        px = QPixmap(os.path.join(self.plugin_dir, "icon.png"))
        logo.setPixmap(px.scaled(48, 48, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo.setFixedSize(52, 52)
        hdr.addWidget(logo)
        txt = QVBoxLayout()
        txt.addWidget(QLabel("<b style='font-size:14px'>Extraction des Zonages Économiques</b>"))
        txt.addWidget(QLabel(
            "<span style='color:#555;font-size:11px'>"
            "Extraction des zonages économiques et fusion des entités selon le type du zonage :  U / 1AU / 2AU</span>"
        ))
        hdr.addLayout(txt)
        hdr.addStretch()
        layout.addLayout(hdr)

        # ── Groupe 1 : EPCI + Département ────────────────────────────────────
        grp1 = QGroupBox("1 — Sélection de la collectivité et de la nommenclature des zonages")
        g1 = QVBoxLayout()
        g1.setSpacing(6)

        g1.addWidget(QLabel("Couche EPCI/Commune :"))
        self.epci_layer_combo = QComboBox()
        self.epci_layer_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.epci_layer_combo.currentIndexChanged.connect(self._reload_epci_names)
        g1.addWidget(self.epci_layer_combo)

        g1.addWidget(QLabel("Nom de l'EPCI ou de la Commune :"))
        self.epci_name_combo = QComboBox()
        self.epci_name_combo.setEditable(False)
        self.epci_name_combo.setMinimumHeight(30)
        self.epci_name_combo.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.epci_name_combo.setMinimumContentsLength(50)
        self.epci_name_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        g1.addWidget(self.epci_name_combo)

        g1.addWidget(QLabel("Nommenclature du zonage :"))
        self.dept_combo = QComboBox()
        for key, cfg in DEPT_CONFIG.items():
            self.dept_combo.addItem(cfg["label"], key)
        self.dept_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        g1.addWidget(self.dept_combo)

        grp1.setLayout(g1)
        layout.addWidget(grp1)

        # ── Groupe 2 : Couches sources (optionnelles) ─────────────────────────
        grp2 = QGroupBox("2 — Couches sources  (cochez au moins une)")
        g2 = QVBoxLayout()
        g2.setSpacing(8)

        self.source_rows = []
        sources_def = [
            ("cu",     "Zonage Complet Urbanisme (Zonage CU) :",  ["urbanisme", "zonage_cu"]),
            ("adauhr", "Zonage ADAUHR :",                         ["adauhr", "adauh"]),
            ("cerema", "Zonage CEREMA (FUSAC) :",                 ["cerema", "fusac"]),
        ]
        for s_type, label, keywords in sources_def:
            row_h = QHBoxLayout()
            chk = QCheckBox()
            chk.setChecked(True)
            chk.setFixedWidth(22)
            lbl = QLabel(label)
            lbl.setMinimumWidth(250)
            combo = QComboBox()
            combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            chk.toggled.connect(combo.setEnabled)
            row_h.addWidget(chk)
            row_h.addWidget(lbl)
            row_h.addWidget(combo)
            g2.addLayout(row_h)
            self.source_rows.append({
                'type': s_type, 'chk': chk,
                'combo': combo, 'keywords': keywords
            })

        grp2.setLayout(g2)
        layout.addWidget(grp2)

        # ── Groupe 3 : Sortie ─────────────────────────────────────────────────
        grp3 = QGroupBox("3 — Couche de sortie")
        g3 = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText(
            "Laisser vide → couche temporaire en mémoire")
        g3.addWidget(self.output_edit)
        btn_br = QPushButton("…")
        btn_br.setFixedWidth(32)
        btn_br.clicked.connect(self._browse_output)
        g3.addWidget(btn_br)
        grp3.setLayout(g3)
        layout.addWidget(grp3)

        # ── Progression ───────────────────────────────────────────────────────
        self.progress = QProgressBar()
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("font-style:italic; color:#444;")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        # ── Boutons ───────────────────────────────────────────────────────────
        btn_row = QHBoxLayout()
        self.btn_run = QPushButton("▶  Lancer le traitement")
        self.btn_run.setStyleSheet(
            "background:#1a5276;color:white;font-weight:bold;"
            "padding:8px 20px;font-size:13px;"
        )
        self.btn_run.clicked.connect(self._start)
        btn_close = QPushButton("Fermer")
        btn_close.clicked.connect(self.reject)
        btn_row.addWidget(self.btn_run)
        btn_row.addWidget(btn_close)
        layout.addLayout(btn_row)

        self.setLayout(layout)

    def _populate_layers(self):
        layers = [l for l in QgsProject.instance().mapLayers().values()
                  if isinstance(l, QgsVectorLayer)]

        self.epci_layer_combo.clear()
        self.epci_layer_combo.addItem("— Sélectionner —", None)
        for l in layers:
            self.epci_layer_combo.addItem(l.name(), l.id())

        for row in self.source_rows:
            row['combo'].clear()
            row['combo'].addItem("— Sélectionner —", None)
            for l in layers:
                row['combo'].addItem(l.name(), l.id())

        def preselect(combo, kws):
            for l in layers:
                if any(k in l.name().lower() for k in kws):
                    idx = combo.findData(l.id())
                    if idx >= 0:
                        combo.setCurrentIndex(idx)
                        return

        preselect(self.epci_layer_combo, ['epci'])
        for row in self.source_rows:
            preselect(row['combo'], row['keywords'])

        self._reload_epci_names()

    def _reload_epci_names(self):
        self.epci_name_combo.clear()
        lid = self.epci_layer_combo.currentData()
        if not lid:
            return
        layer = QgsProject.instance().mapLayer(lid)
        if not layer:
            return
        idx = layer.fields().indexOf("NOM_M")
        if idx < 0:
            self.epci_name_combo.addItem("⚠ Champ NOM_M introuvable")
            return
        values = sorted(set(
            str(f.attribute("NOM_M"))
            for f in layer.getFeatures()
            if f.attribute("NOM_M") not in (None, "")
        ))
        for v in values:
            self.epci_name_combo.addItem(v)

    def _browse_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Enregistrer la couche résultat", "",
            "GeoPackage (*.gpkg);;Shapefile (*.shp)"
        )
        if path:
            self.output_edit.setText(path)

    def _start(self):
        errors = []
        if not self.epci_layer_combo.currentData():
            errors.append("• Couche EPCI/Commune manquante")
        nom = self.epci_name_combo.currentText()
        if not nom or "⚠" in nom:
            errors.append("• Nom invalide")

        sources_active = []
        for row in self.source_rows:
            if row['chk'].isChecked():
                lid = row['combo'].currentData()
                if not lid:
                    errors.append(
                        "• Couche '" + row['type'] + "' cochée mais non sélectionnée")
                else:
                    layer = QgsProject.instance().mapLayer(lid)
                    if layer:
                        sources_active.append(
                            {'type': row['type'], 'layer': layer})

        if not sources_active and not errors:
            errors.append("• Cochez et sélectionnez au moins une couche source")

        if errors:
            QMessageBox.warning(self, "Paramètres incomplets",
                                "Veuillez corriger :\n" + "\n".join(errors))
            return

        params = {
            'epci_layer':  QgsProject.instance().mapLayer(
                               self.epci_layer_combo.currentData()),
            'NOM_M':    nom,
            'dept_key':    self.dept_combo.currentData(),
            'sources':     sources_active,
            'output_path': self.output_edit.text().strip() or 'memory:',
        }

        self.btn_run.setEnabled(False)
        self.progress.setValue(0)
        self.status_label.setText("Initialisation…")
        self.status_label.setStyleSheet("font-style:italic; color:#1a5276;")

        self.thread = ProcessingThread(params)
        self.thread.progress_changed.connect(
            lambda pct, msg: (self.progress.setValue(pct),
                              self.status_label.setText(msg)))
        self.thread.finished_ok.connect(self._on_success)
        self.thread.finished_error.connect(self._on_error)
        self.thread.start()

    def _on_success(self, result_layer):
        self.progress.setValue(100)
        nom = self.epci_name_combo.currentText()
        layer_name = "ZONAGE_ECO_" + nom

        if isinstance(result_layer, QgsVectorLayer):
            result_layer.setName(layer_name)
            QgsProject.instance().addMapLayer(result_layer)
            n = result_layer.featureCount()
        else:
            out = QgsVectorLayer(str(result_layer), layer_name, "ogr")
            QgsProject.instance().addMapLayer(out)
            n = out.featureCount()

        self.status_label.setText("✅ Terminé — " + str(n) + " entité(s) créée(s)")
        self.status_label.setStyleSheet("color:green; font-weight:bold;")
        self.btn_run.setEnabled(True)
        QMessageBox.information(self, "Succès",
            "Traitement terminé !\n\nLa couche '" + layer_name +
            "' a été ajoutée au projet.\n" + str(n) + " entité(s) créée(s).")

    def _on_error(self, msg):
        self.progress.setValue(0)
        self.status_label.setText("❌ Erreur — voir détails")
        self.status_label.setStyleSheet("color:red; font-weight:bold;")
        self.btn_run.setEnabled(True)
        QMessageBox.critical(self, "Erreur de traitement",
                             "Une erreur est survenue :\n\n" + msg)
