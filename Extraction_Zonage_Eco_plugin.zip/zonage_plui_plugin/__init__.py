# -*- coding: utf-8 -*-
def classFactory(iface):
    from .zonage_plui import ZonagePLUiPlugin
    return ZonagePLUiPlugin(iface)
